import { Component } from '@angular/core';

@Component({
  selector: 'app-assetpandmattributelist',
  templateUrl: './assetpandmattributelist.component.html',
  styleUrls: ['./assetpandmattributelist.component.scss']
})
export class AssetpandmattributelistComponent {

}
