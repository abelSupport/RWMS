import { Component } from '@angular/core';

@Component({
  selector: 'app-google-pothole-complaint-form',
  templateUrl: './google-pothole-complaint-form.component.html',
  styleUrls: ['./google-pothole-complaint-form.component.scss']
})
export class GooglePotholeComplaintFormComponent {

}
