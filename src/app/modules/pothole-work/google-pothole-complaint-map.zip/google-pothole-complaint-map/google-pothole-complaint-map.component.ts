import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-google-pothole-complaint-map',
  templateUrl: './google-pothole-complaint-map.component.html',
  styleUrls: ['./google-pothole-complaint-map.component.scss']
})
export class GooglePotholeComplaintMapComponent implements OnInit{
  map: google.maps.Map;
  marker: google.maps.Marker;

  lat = 19.116625;
  lng = 72.862358;
  zoom: number = 12;
  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.mapInit();
    this.initAutocomplete();
    this.loadGeoJsonLayer();
    this.addMapClickListener();

  }

  mapInit(){
    const mapOptions = {
      center: { lat: this.lat, lng: this.lng },
      zoom: this.zoom
    };

    this.map = new google.maps.Map(document.getElementById('map') as HTMLElement, mapOptions);
  
  }

  initAutocomplete() {
    const input = document.getElementById('search-box') as HTMLInputElement;
    const autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', this.map);

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      if (!place.geometry || !place.geometry.location) {
        return;
      }

      if (place.geometry.viewport) {
        this.map.fitBounds(place.geometry.viewport);
      } else {
        this.map.setCenter(place.geometry.location);
        this.map.setZoom(17); 
      }

      const marker = new google.maps.Marker({
        map: this.map,
        position: place.geometry.location
      });
    });
  }

  addMapClickListener() {

    this.map.data.addListener('click', (event) => {
      console.log(event);
      
      google.maps.event.trigger(this.map, 'click', {
        latLng: event.latLng
      });
      this.addMarker(event.latLng)
    });
  }

  addMarker(location: google.maps.LatLng | google.maps.LatLngLiteral) {
    if (this.marker) {
      this.marker.setMap(null);
    }
    console.log(location);
    
    this.marker = new google.maps.Marker({
      position: location,
      map: this.map
    });
  }

  loadGeoJsonLayer() {
    this.http.get('https://roads.mcgm.gov.in:3000/api/geo/getwardlayer').subscribe((data: any) => {
      this.map.data.addGeoJson(data);
      this.setMapStyle();
      this.addFeatureNames();
    });
  }

  setMapStyle() {
    this.map.data.setStyle({
      fillColor: 'blue',
      strokeWeight: 1
    });
  }

  addFeatureNames() {
    this.map.data.addListener('addfeature', (event) => {
      const feature = event.feature.Gg;
      console.log(feature);
      
      const name = feature.getProperty('wardname');

      const bounds = new google.maps.LatLngBounds();
      feature.getGeometry().forEachLatLng(function(latlng) {
        bounds.extend(latlng);
      });

      const center = bounds.getCenter();
      new google.maps.Marker({
        position: center,
        map: this.map,
        label: name,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 0 // Hide the marker icon, only show the label
        }
      });
    });
  }
}
